﻿namespace PsiTemp.Initialization
{
    public class PluginInfo
    {
        public const string menuGUID = "com.psi.psimenu.org";
        public const string menuName = "Psi Menu";
        public const string menuVersion = "1.0";
    }
}
