﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Text;
using UnityEngine.InputSystem;
using UnityEngine;
using Object = UnityEngine.Object;
using static PsiTemp.Utilities.ColorLib;
using static PsiTemp.Utilities.Variables;
using static PsiTemp.Menu.Main;
using static PsiTemp.Menu.ButtonHandler;
using static PsiTemp.Menu.Optimizations;
using PsiTemp.Utilities;
using PsiTemp.Menu;
using static PsiTemp.Mods.Categories.Move;
using static PsiTemp.Utilities.Patches.OtherPatches;
using static PsiTemp.Utilities.GunTemplate;
using System.Linq;
using Oculus.Platform;
using Photon.Pun;

namespace PsiTemp.Mods.Categories
{
    public class Settings
    {
        public static void SwitchHands(bool setActive)
        {
            rightHandedMenu = setActive;
        }

        public static void ClearNotifications()
        {
            NotificationLib.ClearAllNotifications();
        }

        public static void ToggleNotifications(bool setActive)
        {
            toggleNotifications = setActive;
        }

        public static void ToggleDisconnectButton(bool setActive)
        {
            toggledisconnectButton = setActive;
        }
        public static void Discord()
        {
            UnityEngine.Application.OpenURL("https://discord.gg/WFJ9nJQxnr");
        }

    }
}
