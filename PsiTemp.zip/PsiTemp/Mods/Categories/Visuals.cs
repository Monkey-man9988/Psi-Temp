﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using static PsiTemp.Utilities.Variables;
using static PsiTemp.Utilities.ColorLib;
using static PsiTemp.Mods.Categories.Settings;
using static PsiTemp.Menu.Main;
using Photon.Pun;
using Object = UnityEngine.Object;
using System.Linq;
using Photon.Realtime;
using UnityEngine.InputSystem.Controls;
using System.Drawing;
using System.Xml.Linq;
using PsiTemp.Utilities;


namespace PsiTemp.Mods.Categories
{
    public class Visuals 
    {
        
    }
}

