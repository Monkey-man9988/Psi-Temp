﻿using System;
using System.Collections.Generic;
using System.Text;
using static PsiTemp.Utilities.GunTemplate;
using static PsiTemp.Utilities.ColorLib;
using static PsiTemp.Utilities.Variables;
using static PsiTemp.Menu.Main;
using static PsiTemp.Mods.Categories.Settings;
using UnityEngine;
using UnityEngine.InputSystem;
using PsiTemp.Utilities;
using UnityEngine.XR;
using UnityEngine.Animations.Rigging;
using UnityEngine.XR.Interaction.Toolkit;
using GorillaNetworking;
using PsiTemp.Utilities.Patches;
using PsiTemp.Menu;
using ExitGames.Client.Photon;
using Photon.Pun;
using Photon.Realtime;
using HarmonyLib;
using BepInEx;
using PsiTemp.Utilities;

namespace PsiTemp.Mods.Categories
{
    public class Playerr
    {
       
    }
}
